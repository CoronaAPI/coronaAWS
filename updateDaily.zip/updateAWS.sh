#!/bin/bash

zip -r updateDaily.zip .

aws lambda update-function-code --function-name dailyCases --zip-file fileb://$(pwd)/dailyCases.zip

